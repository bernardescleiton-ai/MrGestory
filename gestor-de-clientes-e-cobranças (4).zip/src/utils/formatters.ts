import { Client, Charge, CompanySettings } from '../types';

export const brl = (v: number): string => {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v || 0);
};

export const dateBR = (s: string): string => {
  if (!s || typeof s !== 'string') return '';
  return new Date(s + 'T12:00:00').toLocaleDateString('pt-BR');
};

export const todayStr = (): string => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const normalizePhone = (p: string): string => {
  if (!p) return '';
  return p.replace(/\D/g, '');
};

export type ChargeStatus = 'pending' | 'paid' | 'late';

export const getChargeStatus = (c: Charge): ChargeStatus => {
  if (c.paid) return 'paid';
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(c.dueDate + 'T12:00:00');
  return due < today ? 'late' : 'pending';
};

export const getDefaultMessage = (client: Client, charge: Charge | null | undefined, settings: CompanySettings): string => {
  const dueStr = charge ? (charge.dueTime ? `${dateBR(charge.dueDate)} às ${charge.dueTime}` : dateBR(charge.dueDate)) : (client.dueDate ? formatDateTimeBR(client.dueDate) : 'a definir');
  const template = settings?.messageTemplate || 'Olá, {nome}! Tudo bem?\n\nPassando para lembrar que seu vencimento está agendado para o dia *{vencimento}*.{nota}';
  
  const noteText = charge?.note ? `\nObservação: ${charge.note}` : '';

  let msg = template
    .replace(/{nome}/g, client.name)
    .replace(/{vencimento}/g, dueStr)
    .replace(/{valor}/g, '')
    .replace(/{nota}/g, noteText);

  if (settings?.signature) {
    msg += `\n\n${settings.signature}`;
  }
  return msg;
};

export const openWhatsApp = (client: Client, charge: Charge | null | undefined, settings: CompanySettings) => {
  const phone = normalizePhone(client.phone);
  if (!phone) {
    alert('Cliente sem WhatsApp cadastrado.');
    return;
  }
  const msg = encodeURIComponent(getDefaultMessage(client, charge, settings));
  window.open(`https://wa.me/55${phone}?text=${msg}`, '_blank');
};

export const openDirectWhatsApp = (client: Client, settings: CompanySettings) => {
  const phone = normalizePhone(client.phone);
  if (!phone) {
    alert('Cliente sem WhatsApp cadastrado.');
    return;
  }
  const dueDateFormatted = client.dueDate ? formatDateTimeBR(client.dueDate) : 'a definir';
  const template = settings?.messageTemplate || 'Olá, {nome}! Tudo bem?\n\nPassando para lembrar sobre o seu vencimento cadastrado para: *{vencimento}*.';
  
  let msg = template
    .replace(/{nome}/g, client.name)
    .replace(/{vencimento}/g, dueDateFormatted)
    .replace(/{valor}/g, '')
    .replace(/{nota}/g, '');

  if (settings?.signature) {
    msg += `\n\n${settings.signature}`;
  }
  
  const encoded = encodeURIComponent(msg);
  window.open(`https://wa.me/55${phone}?text=${encoded}`, '_blank');
};

export const formatDateTimeBR = (isoStr?: string): string => {
  if (!isoStr) return '—';
  const [datePart, timePart] = isoStr.split('T');
  if (!datePart) return isoStr;
  const formattedDate = dateBR(datePart);
  return timePart ? `${formattedDate} às ${timePart}` : formattedDate;
};

export const getClientStatusBadge = (dueDateStr?: string) => {
  if (!dueDateStr || typeof dueDateStr !== 'string') {
    return {
      label: 'Sem Vencimento',
      className: 'bg-slate-100 text-slate-600 border border-slate-200',
    };
  }

  const datePart = dueDateStr.split('T')[0];
  if (!datePart) {
    return {
      label: 'Sem Vencimento',
      className: 'bg-slate-100 text-slate-600 border border-slate-200',
    };
  }
  const [y, m, d] = datePart.split('-').map(Number);
  if (!y || !m || !d) {
    return {
      label: 'Sem Vencimento',
      className: 'bg-slate-100 text-slate-600 border border-slate-200',
    };
  }

  const today = new Date();
  const todayReset = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const dueReset = new Date(y, m - 1, d);

  const diffMs = dueReset.getTime() - todayReset.getTime();
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) {
    return {
      label: 'Vence Hoje',
      className: 'bg-amber-100 text-amber-800 border border-amber-300 font-bold',
    };
  } else if (diffDays > 0) {
    const label = diffDays === 1 ? 'Vence em 1 dia' : `Vence em ${diffDays} dias`;
    return {
      label,
      className: 'bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold',
    };
  } else {
    const overdueDays = Math.abs(diffDays);
    const label = overdueDays === 1 ? 'Atrasado (1 dia)' : `Atrasado (${overdueDays} dias)`;
    return {
      label,
      className: 'bg-rose-100 text-rose-800 border border-rose-300 font-bold',
    };
  }
};


