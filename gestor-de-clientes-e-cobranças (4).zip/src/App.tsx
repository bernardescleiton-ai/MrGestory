import React, { useState, useEffect, useRef } from 'react';
import { Trash2, Bell, X, MessageCircle, RefreshCw } from 'lucide-react';
import { AppData, SectionType, Client, Charge, CompanySettings, SentMessageLog } from './types';
import { initialAppData } from './data/initialData';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { ClientsView } from './components/ClientsView';
import { ChargesView } from './components/ChargesView';
import { DueView } from './components/DueView';
import { SettingsView } from './components/SettingsView';
import { NotificationsView } from './components/NotificationsView';
import { ClientModal } from './components/ClientModal';
import { ChargeModal } from './components/ChargeModal';
import { ClientHistoryModal } from './components/ClientHistoryModal';
import { openWhatsApp, openDirectWhatsApp, normalizePhone, getDefaultMessage } from './utils/formatters';
import { checkAndTriggerDeviceNotifications } from './utils/notifications';
import { subscribeToApiData, saveAppData, sanitizeAppData } from './lib/api';

const STORAGE_KEY = 'gc_v1_data';

const generateUUID = () => {
  if (typeof window !== 'undefined' && window.crypto && typeof window.crypto.randomUUID === 'function') {
    return window.crypto.randomUUID();
  }
  return 'f' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

export default function App() {
  const [data, setRawData] = useState<AppData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return sanitizeAppData(JSON.parse(saved));
      }
    } catch (e) {
      console.error('Error loading localStorage:', e);
    }
    return sanitizeAppData({ ...initialAppData, updatedAt: 1 });
  });

  const isRemoteUpdate = useRef<boolean>(false);
  const dataRef = useRef<AppData>(data);
  dataRef.current = data;

  // Custom setter that automatically adds or updates 'updatedAt' for local changes
  const setData = (update: AppData | ((prev: AppData) => AppData)) => {
    setRawData((prev) => {
      const next = typeof update === 'function' ? update(prev) : update;
      isRemoteUpdate.current = false;
      return sanitizeAppData({
        ...next,
        updatedAt: Date.now(),
      });
    });
  };

  const [activeSection, setActiveSection] = useState<SectionType>('dashboard');

  // Live Toast Notification
  const [liveToast, setLiveToast] = useState<{
    title: string;
    body: string;
    phone?: string;
    clientMessage?: string;
    client?: Client;
    charge?: Charge;
  } | null>(null);

  // Modals state
  const [isClientModalOpen, setIsClientModalOpen] = useState(false);
  const [clientToEdit, setClientToEdit] = useState<Client | null>(null);

  const [isChargeModalOpen, setIsChargeModalOpen] = useState(false);
  const [chargeDefaultClientId, setChargeDefaultClientId] = useState<string | undefined>(undefined);

  const [historyClient, setHistoryClient] = useState<Client | null>(null);

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const [syncTrigger, setSyncTrigger] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);

  const handleManualSync = async () => {
    if (isSyncing) return;
    setIsSyncing(true);
    setSyncError(null);
    try {
      // 1. Manually write local state to REST API immediately to guarantee sync
      await saveAppData(dataRef.current, 0);

      // 2. Trigger fetch
      setSyncTrigger((prev) => prev + 1);
      
      // Wait slightly (400ms) to give feedback
      await new Promise((resolve) => setTimeout(resolve, 400));
    } catch (err) {
      console.warn('Manual sync notice:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  // Re-establish REST API listener on focus, visibility change, online status, or periodic heartbeat
  useEffect(() => {
    const handleSyncReset = () => {
      setSyncTrigger((prev) => prev + 1);
    };

    window.addEventListener('focus', handleSyncReset);
    window.addEventListener('online', handleSyncReset);
    
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        handleSyncReset();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Periodic heartbeat every 15 seconds to sync data across active tabs / mobile apps
    const heartbeat = setInterval(handleSyncReset, 15000);

    return () => {
      window.removeEventListener('focus', handleSyncReset);
      window.removeEventListener('online', handleSyncReset);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      clearInterval(heartbeat);
    };
  }, []);

  // 1. Listen to Real-Time REST API Backend Updates (Sync between URL Web App & APK)
  useEffect(() => {
    const unsubscribe = subscribeToApiData(
      (cloudData, exists) => {
        const localData = dataRef.current;
        setSyncError(null);

        if (!exists) {
          // Data does not exist on Server yet. Seed server with local data.
          saveAppData(localData, 0).catch(() => {});
          return;
        }

        const safeCloud = sanitizeAppData(cloudData);
        const cloudTime = safeCloud.updatedAt || 0;
        const localTime = localData.updatedAt || 0;

        if (cloudTime >= localTime || localTime === 1) {
          // Server data is newer or same: apply it locally
          isRemoteUpdate.current = true;
          setRawData(safeCloud);
          try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(safeCloud));
          } catch {
            // local storage fallback
          }
        } else if (localTime > cloudTime) {
          // Local is newer: push it to server
          saveAppData(localData, 0).catch(() => {});
        }
      },
      (error) => {
        // Keep previous state gracefully without breaking UI
        console.warn('Sync stream notice:', error);
      }
    );

    return () => unsubscribe();
  }, [syncTrigger]);

  // 2. Persist changes locally and to REST API backend
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));

      if (isRemoteUpdate.current) {
        isRemoteUpdate.current = false;
      } else {
        saveAppData(data)
          .then(() => {
            setSyncError(null);
          })
          .catch((err) => {
            setSyncError(err instanceof Error ? err.message : String(err));
          });
      }

      checkAndTriggerDeviceNotifications(data, (alertData) => {
        setLiveToast(alertData);
      });
    } catch (e) {
      console.error('Error saving data:', e);
    }
  }, [data]);

  // Real-time 5-second interval check for exact hour/minute notifications
  useEffect(() => {
    checkAndTriggerDeviceNotifications(data, (alertData) => {
      setLiveToast(alertData);
    });

    const interval = setInterval(() => {
      checkAndTriggerDeviceNotifications(data, (alertData) => {
        setLiveToast(alertData);
      });
    }, 5000);
    return () => clearInterval(interval);
  }, [data]);

  // Client handlers
  const handleOpenNewClient = () => {
    setClientToEdit(null);
    setIsClientModalOpen(true);
  };

  const handleOpenEditClient = (client: Client) => {
    setClientToEdit(client);
    setIsClientModalOpen(true);
  };

  const handleSaveClient = (clientData: Omit<Client, 'id' | 'createdAt'>, editId?: string) => {
    setData((prev) => {
      let updatedClients = [...prev.clients];
      let updatedCharges = [...prev.charges];
      const targetClientId = editId || generateUUID();

      if (editId) {
        updatedClients = updatedClients.map((c) => (c.id === editId ? { ...c, ...clientData } : c));
      } else {
        const newClient: Client = {
          id: targetClientId,
          ...clientData,
          createdAt: new Date().toISOString(),
        };
        updatedClients = [newClient, ...updatedClients];
      }

      // If clientData has a dueDate set, ensure an active charge exists or update the existing charge
      if (targetClientId) {
        if (clientData.dueDate) {
          const fullDt = clientData.dueDate;
          const [datePart, timePart] = fullDt.includes('T') ? fullDt.split('T') : [fullDt, ''];

          // Find existing unpaid charge for this client
          const existingChargeIndex = updatedCharges.findIndex(
            (ch) => ch.clientId === targetClientId && !ch.paid
          );

          if (existingChargeIndex >= 0) {
            updatedCharges[existingChargeIndex] = {
              ...updatedCharges[existingChargeIndex],
              dueDate: datePart,
              dueTime: timePart || undefined,
            };
          } else {
            const newCharge: Charge = {
              id: generateUUID(),
              clientId: targetClientId,
              amount: 0,
              dueDate: datePart,
              dueTime: timePart || undefined,
              paid: false,
              note: 'Vencimento do Cliente',
              createdAt: new Date().toISOString(),
            };
            updatedCharges = [newCharge, ...updatedCharges];
          }
        } else {
          // If due date was removed/cleared, remove the unpaid automatic charge
          updatedCharges = updatedCharges.filter(
            (ch) => !(ch.clientId === targetClientId && !ch.paid && ch.note === 'Vencimento do Cliente')
          );
        }
      }

      return {
        ...prev,
        clients: updatedClients,
        charges: updatedCharges,
      };
    });
  };

  const handleDeleteClient = (clientId: string) => {
    const client = data.clients.find((c) => c.id === clientId);
    setConfirmModal({
      isOpen: true,
      title: 'Excluir Cliente',
      message: `Deseja realmente excluir o cliente "${client?.name || 'Cliente'}"? Todas as cobranças associadas a ele também serão removidas.`,
      onConfirm: () => {
        setData((prev) => ({
          ...prev,
          clients: prev.clients.filter((c) => c.id !== clientId),
          charges: prev.charges.filter((ch) => ch.clientId !== clientId),
        }));
        if (historyClient?.id === clientId) {
          setHistoryClient(null);
        }
        setConfirmModal((prev) => ({ ...prev, isOpen: false }));
      },
    });
  };

  // Charge handlers
  const handleOpenNewCharge = (defaultClientId?: string) => {
    if (data.clients.length === 0) {
      alert('Você precisa cadastrar pelo menos um cliente antes de criar uma cobrança.');
      setActiveSection('clients');
      return;
    }
    setChargeDefaultClientId(defaultClientId || data.clients[0].id);
    setIsChargeModalOpen(true);
  };

  const handleSaveCharge = (chargeData: Omit<Charge, 'id' | 'createdAt' | 'paid'>) => {
    const newCharge: Charge = {
      id: generateUUID(),
      ...chargeData,
      paid: false,
      createdAt: new Date().toISOString(),
    };
    setData((prev) => ({
      ...prev,
      charges: [newCharge, ...prev.charges],
    }));
  };

  const handleMarkPaid = (chargeId: string) => {
    setData((prev) => {
      // 1. Handle Virtual Charges
      if (chargeId.startsWith('client-charge-')) {
        const clientId = chargeId.replace('client-charge-', '');
        const client = prev.clients.find((c) => c.id === clientId);
        if (!client || !client.dueDate) return prev;

        // Create a real paid charge record in history
        const [datePart, timePart] = client.dueDate.split('T');
        const newPaidCharge: Charge = {
          id: generateUUID(),
          clientId: client.id,
          amount: 0,
          dueDate: datePart,
          dueTime: timePart || undefined,
          note: 'Mensalidade do Cliente',
          paid: true,
          paidAt: new Date().toISOString(),
          createdAt: new Date().toISOString(),
        };

        // Advance client's dueDate by exactly 1 month
        const currentDate = new Date(client.dueDate);
        currentDate.setMonth(currentDate.getMonth() + 1);
        const nextDueDateStr = currentDate.toISOString().slice(0, 16); // YYYY-MM-DDTHH:mm

        return {
          ...prev,
          charges: [newPaidCharge, ...prev.charges],
          clients: prev.clients.map((c) =>
            c.id === clientId ? { ...c, dueDate: nextDueDateStr } : c
          ),
        };
      }

      // 2. Handle Real Charges
      const targetCharge = prev.charges.find((ch) => ch.id === chargeId);
      if (!targetCharge) return prev;

      let updatedClients = prev.clients;
      const client = prev.clients.find((c) => c.id === targetCharge.clientId);
      
      // If this real charge was matching the client's profile dueDate, advance the client's profile dueDate too!
      if (client && client.dueDate) {
        const [clientDatePart] = client.dueDate.split('T');
        if (targetCharge.dueDate === clientDatePart) {
          const currentDate = new Date(client.dueDate);
          currentDate.setMonth(currentDate.getMonth() + 1);
          const nextDueDateStr = currentDate.toISOString().slice(0, 16);

          updatedClients = prev.clients.map((c) =>
            c.id === client.id ? { ...c, dueDate: nextDueDateStr } : c
          );
        }
      }

      return {
        ...prev,
        clients: updatedClients,
        charges: prev.charges.map((ch) =>
          ch.id === chargeId ? { ...ch, paid: true, paidAt: new Date().toISOString() } : ch
        ),
      };
    });
  };

  const handleUndoPaid = (chargeId: string) => {
    setData((prev) => {
      const targetCharge = prev.charges.find((ch) => ch.id === chargeId);
      if (!targetCharge) return prev;

      let updatedClients = prev.clients;
      const client = prev.clients.find((c) => c.id === targetCharge.clientId);
      
      // Symmetrically roll back the client's profile dueDate by exactly 1 month if we are undoing their payment
      if (client && client.dueDate) {
        const currentDate = new Date(client.dueDate);
        currentDate.setMonth(currentDate.getMonth() - 1);
        const prevDueDateStr = currentDate.toISOString().slice(0, 16);

        const nextMonthOfCharge = new Date(targetCharge.dueDate + 'T12:00:00');
        nextMonthOfCharge.setMonth(nextMonthOfCharge.getMonth() + 1);
        const [nextMonthOfChargeDatePart] = nextMonthOfCharge.toISOString().split('T');
        const [clientDatePart] = client.dueDate.split('T');

        if (clientDatePart === nextMonthOfChargeDatePart) {
          updatedClients = prev.clients.map((c) =>
            c.id === client.id ? { ...c, dueDate: prevDueDateStr } : c
          );
        }
      }

      return {
        ...prev,
        clients: updatedClients,
        charges: prev.charges.map((ch) => {
          if (ch.id === chargeId) {
            const { paidAt, ...rest } = ch;
            return { ...rest, paid: false };
          }
          return ch;
        }),
      };
    });
  };

  const handleDeleteCharge = (chargeId: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Excluir Cobrança',
      message: 'Deseja excluir esta cobrança permanentemente?',
      onConfirm: () => {
        setData((prev) => ({
          ...prev,
          charges: prev.charges.filter((ch) => ch.id !== chargeId),
        }));
        setConfirmModal((prev) => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleSaveSettings = (newSettings: CompanySettings) => {
    setData((prev) => ({
      ...prev,
      settings: newSettings,
    }));
  };

  const handleSendWhatsApp = (client: Client, charge?: Charge) => {
    if (charge) {
      openWhatsApp(client, charge, data.settings);
    } else {
      openDirectWhatsApp(client, data.settings);
    }

    const nowIso = new Date().toISOString();
    const newLog: SentMessageLog = {
      id: generateUUID(),
      clientId: client.id,
      clientName: client.name,
      phone: client.phone,
      chargeId: charge?.id,
      dueDate: charge?.dueDate || client.dueDate,
      sentAt: nowIso,
      messageText: charge ? getDefaultMessage(client, charge, data.settings) : 'Lembrete de vencimento enviado',
      note: charge?.note,
      status: 'enviado',
    };

    setData((prev) => {
      const updatedCharges = charge
        ? prev.charges.map((ch) =>
            ch.id === charge.id ? { ...ch, messageSent: true, messageSentAt: nowIso } : ch
          )
        : prev.charges;

      return {
        ...prev,
        charges: updatedCharges,
        sentLogs: [newLog, ...(prev.sentLogs || [])],
      };
    });
  };

  const handleDeleteSentLog = (logId: string) => {
    setData((prev) => ({
      ...prev,
      sentLogs: (prev.sentLogs || []).filter((l) => l.id !== logId),
    }));
  };

  const handleToggleMessageSent = (chargeId: string) => {
    setData((prev) => ({
      ...prev,
      charges: prev.charges.map((ch) => {
        if (ch.id === chargeId) {
          const isSent = !ch.messageSent;
          return {
            ...ch,
            messageSent: isSent,
            messageSentAt: isSent ? new Date().toISOString() : undefined,
          };
        }
        return ch;
      }),
    }));
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col md:flex-row font-sans text-slate-900 antialiased selection:bg-blue-600 selection:text-white">
      {/* Mobile Top Header */}
      <header className="md:hidden bg-[#0F172A] text-white px-4 py-3 flex items-center justify-between border-b border-slate-800 sticky top-0 z-30 shadow-sm">
        <div className="flex items-center space-x-2.5">
          <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xs shadow-xs">
            M
          </div>
          <span className="font-bold text-sm tracking-tight text-white">MrGestor</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleManualSync}
            disabled={isSyncing}
            className="p-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg text-slate-300 active:scale-95 transition-all disabled:opacity-50"
            title="Sincronizar dados agora"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-blue-400' : ''}`} />
          </button>
        </div>
      </header>

      {/* Sidebar / Nav */}
      <Sidebar 
        activeSection={activeSection} 
        onSelectSection={setActiveSection} 
        onSync={handleManualSync}
        isSyncing={isSyncing}
        syncError={syncError}
      />

      {/* Main Content Area */}
      <main className="flex-1 md:ml-64 p-3.5 sm:p-8 max-w-7xl w-full mx-auto pb-24 md:pb-12">
        {activeSection === 'dashboard' && (
          <DashboardView
            data={data}
            onNavigate={setActiveSection}
            onOpenNewClient={handleOpenNewClient}
            onMarkPaid={handleMarkPaid}
            onSendWhatsApp={handleSendWhatsApp}
          />
        )}

        {activeSection === 'clients' && (
          <ClientsView
            clients={data.clients}
            onOpenNewClient={handleOpenNewClient}
            onOpenEditClient={handleOpenEditClient}
            onDeleteClient={handleDeleteClient}
            onOpenHistory={setHistoryClient}
            onSendWhatsApp={(client) => handleSendWhatsApp(client)}
          />
        )}

        {activeSection === 'charges' && (
          <ChargesView
            clients={data.clients}
            charges={data.charges}
            settings={data.settings}
            sentLogs={data.sentLogs}
            onMarkPaid={handleMarkPaid}
            onUndoPaid={handleUndoPaid}
            onDeleteCharge={handleDeleteCharge}
            onSendWhatsApp={handleSendWhatsApp}
            onDeleteSentLog={handleDeleteSentLog}
            onToggleMessageSent={handleToggleMessageSent}
          />
        )}

        {activeSection === 'due' && (
          <DueView
            clients={data.clients}
            charges={data.charges}
            settings={data.settings}
            onMarkPaid={handleMarkPaid}
            onSendWhatsApp={handleSendWhatsApp}
          />
        )}

        {activeSection === 'notifications' && (
          <NotificationsView
            clients={data.clients}
            charges={data.charges}
            settings={data.settings}
            onSaveSettings={handleSaveSettings}
            onSendWhatsApp={handleSendWhatsApp}
          />
        )}

        {activeSection === 'settings' && (
          <SettingsView
            settings={data.settings}
            onSaveSettings={handleSaveSettings}
            clients={data.clients}
            charges={data.charges}
            onImportData={(newData) => {
              setData((prev) => ({
                ...prev,
                settings: newData.settings || prev.settings,
                clients: newData.clients || prev.clients,
                charges: newData.charges || prev.charges,
              }));
            }}
          />
        )}
      </main>

      {/* Modals */}
      <ClientModal
        isOpen={isClientModalOpen}
        onClose={() => setIsClientModalOpen(false)}
        onSave={handleSaveClient}
        clientToEdit={clientToEdit}
      />

      <ChargeModal
        isOpen={isChargeModalOpen}
        onClose={() => setIsChargeModalOpen(false)}
        onSave={handleSaveCharge}
        clients={data.clients}
        defaultClientId={chargeDefaultClientId}
      />

      <ClientHistoryModal
        isOpen={!!historyClient}
        onClose={() => setHistoryClient(null)}
        client={historyClient}
        charges={data.charges}
        settings={data.settings}
        onMarkPaid={handleMarkPaid}
        onUndoPaid={handleUndoPaid}
        onSendWhatsApp={handleSendWhatsApp}
        onNewChargeForClient={(clientId) => {
          setHistoryClient(null);
          handleOpenNewCharge(clientId);
        }}
      />

      {/* Real-time In-App Live Alert Toast */}
      {liveToast && (
        <div className="fixed top-5 right-5 z-50 max-w-md w-full animate-in slide-in-from-top-4 duration-300">
          <div className="bg-slate-900 text-white rounded-2xl shadow-2xl p-4 border border-slate-700 space-y-3">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-rose-600 rounded-xl shrink-0 mt-0.5 animate-pulse">
                <Bell className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-sm text-white tracking-tight">{liveToast.title}</h4>
                <p className="text-xs text-slate-300 mt-1 font-mono leading-relaxed">{liveToast.body}</p>
              </div>
              <button
                onClick={() => setLiveToast(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {liveToast.clientMessage && (
              <div className="p-3 bg-slate-800/90 rounded-xl border border-slate-700 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                    <MessageCircle className="w-3 h-3 text-emerald-400" />
                    Mensagem definida para o cliente:
                  </span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(liveToast.clientMessage!);
                      alert('Mensagem copiada para a área de transferência!');
                    }}
                    className="text-[10px] text-blue-400 hover:underline cursor-pointer"
                  >
                    Copiar
                  </button>
                </div>
                <p className="text-xs text-slate-200 font-sans italic leading-relaxed whitespace-pre-wrap">
                  "{liveToast.clientMessage}"
                </p>
              </div>
            )}

            <div className="flex items-center gap-2 pt-1">
              {liveToast.client ? (
                <button
                  type="button"
                  onClick={() => {
                    handleSendWhatsApp(liveToast.client!, liveToast.charge);
                    setLiveToast(null);
                  }}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  Enviar WhatsApp ao Cliente
                </button>
              ) : liveToast.phone ? (
                <button
                  type="button"
                  onClick={() => {
                    const num = normalizePhone(liveToast.phone!);
                    if (num) {
                      const msg = liveToast.clientMessage ? encodeURIComponent(liveToast.clientMessage) : '';
                      window.open(`https://wa.me/55${num}?text=${msg}`, '_blank');
                    }
                    setLiveToast(null);
                  }}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  Abrir WhatsApp
                </button>
              ) : null}

              <button
                type="button"
                onClick={() => setLiveToast(null)}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {confirmModal.isOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-100 p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-rose-100 text-rose-600 flex items-center justify-center font-bold">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 text-base">{confirmModal.title}</h3>
              </div>
            </div>
            <p className="text-slate-600 text-xs font-mono leading-relaxed">
              {confirmModal.message}
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmModal((prev) => ({ ...prev, isOpen: false }))}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmModal.onConfirm}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold shadow-2xs transition-colors"
              >
                Sim, excluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
