import React, { useState, useEffect } from 'react';
import { Settings as SettingsIcon, Bell, Smartphone, CheckCircle, AlertCircle, XCircle, Download, Upload, Database, Copy, Check } from 'lucide-react';
import { CompanySettings, Client, Charge, NotificationRules } from '../types';
import {
  getNotificationPermissionStatus,
  requestDeviceNotificationPermission,
  sendTestNotification,
  defaultNotificationRules,
} from '../utils/notifications';

interface SettingsViewProps {
  settings: CompanySettings;
  onSaveSettings: (settings: CompanySettings) => void;
  clients: Client[];
  charges: Charge[];
  onImportData?: (newData: { settings: CompanySettings; clients: Client[]; charges: Charge[] }) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onSaveSettings,
  clients,
  charges,
  onImportData,
}) => {
  const [formData, setFormData] = useState<CompanySettings>(settings);
  const [permStatus, setPermStatus] = useState(getNotificationPermissionStatus());
  const [importCodeInput, setImportCodeInput] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);

  useEffect(() => {
    setFormData(settings);
    setPermStatus(getNotificationPermissionStatus());
  }, [settings]);

  const handleExportJSON = () => {
    const dataToExport = {
      settings: formData,
      clients,
      charges,
      exportedAt: new Date().toISOString(),
    };
    const jsonStr = JSON.stringify(dataToExport, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mrgestor_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyBackupCode = () => {
    const dataToExport = {
      settings: formData,
      clients,
      charges,
    };
    const code = btoa(unescape(encodeURIComponent(JSON.stringify(dataToExport))));
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 3000);
  };

  const handleImportFromText = () => {
    if (!importCodeInput.trim()) {
      alert('Por favor, cole o código de backup ou o JSON para importar.');
      return;
    }
    try {
      let decodedStr = importCodeInput.trim();
      if (!decodedStr.startsWith('{')) {
        decodedStr = decodeURIComponent(escape(atob(decodedStr)));
      }
      const parsed = JSON.parse(decodedStr);
      if (parsed && (parsed.clients || parsed.charges || parsed.settings)) {
        if (onImportData) {
          onImportData({
            settings: parsed.settings || formData,
            clients: parsed.clients || [],
            charges: parsed.charges || [],
          });
          alert('✅ Dados importados e sincronizados com sucesso!');
          setImportCodeInput('');
        }
      } else {
        alert('Formato de backup inválido.');
      }
    } catch (e) {
      alert('Erro ao decodificar backup. Verifique se o código ou arquivo JSON está correto.');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        if (parsed && (parsed.clients || parsed.charges || parsed.settings)) {
          if (onImportData) {
            onImportData({
              settings: parsed.settings || formData,
              clients: parsed.clients || [],
              charges: parsed.charges || [],
            });
            alert('✅ Backup JSON restaurado com sucesso!');
          }
        }
      } catch {
        alert('Erro ao ler arquivo JSON de backup.');
      }
    };
    reader.readAsText(file);
  };

  const currentRules: NotificationRules = formData.notificationRules || defaultNotificationRules;

  const handleToggleRule = (key: keyof NotificationRules) => {
    const updatedRules = {
      ...currentRules,
      [key]: !currentRules[key],
    };
    setFormData({
      ...formData,
      notificationRules: updatedRules,
    });
  };

  const handleRequestPermission = async () => {
    const granted = await requestDeviceNotificationPermission();
    setPermStatus(getNotificationPermissionStatus());
    if (granted) {
      alert('Permissão concedida! As notificações foram ativadas para este dispositivo.');
    } else {
      alert('A permissão para notificações foi negada ou não permitida pelo navegador.');
    }
  };

  const handleSettingsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    alert('Configurações salvas com sucesso!');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Configurações e Meus Dados</h1>
        <p className="text-slate-500 text-xs font-mono mt-0.5">Gerencie os dados da empresa, mensagens, aplicativo e alertas do dispositivo.</p>
      </div>

      {/* Device Push Notifications Config Section */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Notificações Nativas do Dispositivo</h2>
              <p className="text-xs text-slate-500 font-mono">Alertas diretos na tela do celular/navegador</p>
            </div>
          </div>

          {/* Status badge */}
          {permStatus === 'granted' && (
            <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-bold flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" /> Ativo no Dispositivo
            </span>
          )}
          {permStatus === 'default' && (
            <span className="px-2.5 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-bold flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" /> Permissão Pendente
            </span>
          )}
          {(permStatus === 'denied' || permStatus === 'unsupported') && (
            <span className="px-2.5 py-1 bg-rose-100 text-rose-800 rounded-full text-xs font-bold flex items-center gap-1">
              <XCircle className="w-3.5 h-3.5" /> Bloqueado / Inativo
            </span>
          )}
        </div>

        <div className="p-6 space-y-5">
          {/* Permission Request Box */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-blue-100 text-blue-700 rounded-xl shrink-0 mt-0.5">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 text-sm">Permissão de Notificação no Celular</h3>
                <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                  O gestor enviará avisos automáticos na tela do seu dispositivo avisando quando houver clientes com vencimentos próximos ou em atraso.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {permStatus !== 'granted' && (
                <button
                  type="button"
                  onClick={handleRequestPermission}
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors active:scale-95 whitespace-nowrap"
                >
                  Permitir Notificações
                </button>
              )}
              <button
                type="button"
                onClick={sendTestNotification}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors active:scale-95 whitespace-nowrap"
              >
                Testar Alerta Agora
              </button>
            </div>
          </div>

          {/* Trigger rules list */}
          <div className="space-y-3">
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
              Gatilhos de Notificação para o Administrador
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* No dia do vencimento */}
              <label className="p-3 bg-white border border-slate-200 hover:border-blue-300 rounded-xl flex items-center gap-3 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={currentRules.notifyOnDueDate}
                  onChange={() => handleToggleRule('notifyOnDueDate')}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 border-slate-300"
                />
                <div>
                  <span className="block text-xs font-bold text-slate-800">No dia do vencimento</span>
                  <span className="text-[10px] text-slate-500 font-mono">Dispara no dia agendado</span>
                </div>
              </label>

              {/* 1 dia antes */}
              <label className="p-3 bg-white border border-slate-200 hover:border-blue-300 rounded-xl flex items-center gap-3 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={currentRules.notify1DayBefore}
                  onChange={() => handleToggleRule('notify1DayBefore')}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 border-slate-300"
                />
                <div>
                  <span className="block text-xs font-bold text-slate-800">1 dia antes do vencimento</span>
                  <span className="text-[10px] text-slate-500 font-mono">Aviso preventivo na véspera</span>
                </div>
              </label>

              {/* 3 dias antes */}
              <label className="p-3 bg-white border border-slate-200 hover:border-blue-300 rounded-xl flex items-center gap-3 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={currentRules.notify3DaysBefore}
                  onChange={() => handleToggleRule('notify3DaysBefore')}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 border-slate-300"
                />
                <div>
                  <span className="block text-xs font-bold text-slate-800">3 dias antes do vencimento</span>
                  <span className="text-[10px] text-slate-500 font-mono">Lembrete prévio de 3 dias</span>
                </div>
              </label>

              {/* 1 dia de atraso */}
              <label className="p-3 bg-white border border-slate-200 hover:border-blue-300 rounded-xl flex items-center gap-3 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={currentRules.notify1DayAfter}
                  onChange={() => handleToggleRule('notify1DayAfter')}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 border-slate-300"
                />
                <div>
                  <span className="block text-xs font-bold text-slate-800">1 dia após o vencimento (1 dia de atraso)</span>
                  <span className="text-[10px] text-rose-600 font-mono font-semibold">Alerta de atraso inicial</span>
                </div>
              </label>

              {/* 3 dias de atraso */}
              <label className="p-3 bg-white border border-slate-200 hover:border-blue-300 rounded-xl flex items-center gap-3 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={currentRules.notify3DaysAfter}
                  onChange={() => handleToggleRule('notify3DaysAfter')}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 border-slate-300"
                />
                <div>
                  <span className="block text-xs font-bold text-slate-800">3 dias após o vencimento (3 dias de atraso)</span>
                  <span className="text-[10px] text-rose-600 font-mono font-semibold">Alerta de vencimento pendente estendido</span>
                </div>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Company Data Form */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center gap-2 bg-slate-50/50">
          <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
            <SettingsIcon className="w-4 h-4" />
          </div>
          <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Dados da sua empresa / prestador</h2>
        </div>

        <form onSubmit={handleSettingsSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">
              Nome / Empresa *
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full bg-slate-100 border-none rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none text-slate-800"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">
              WhatsApp do Prestador / Empresa
            </label>
            <input
              type="text"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="(48) 99999-9999"
              className="w-full bg-slate-100 border-none rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none text-slate-800 font-mono"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">
              Endereço
            </label>
            <input
              type="text"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full bg-slate-100 border-none rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none text-slate-800"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">
              Modelo de Mensagem do WhatsApp
            </label>
            <textarea
              rows={3}
              value={formData.messageTemplate || ''}
              onChange={(e) => setFormData({ ...formData, messageTemplate: e.target.value })}
              placeholder="Digite sua mensagem personalizada..."
              className="w-full bg-slate-100 border-none rounded-lg p-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none text-slate-800 font-mono"
            />
            <p className="text-[11px] text-slate-500 font-mono mt-1.5">
              🏷️ <strong>Códigos disponíveis:</strong> <code className="bg-slate-200 px-1 py-0.5 rounded font-bold">{'{nome}'}</code> (Nome do cliente) e <code className="bg-slate-200 px-1 py-0.5 rounded font-bold">{'{vencimento}'}</code> (Data/Hora de vencimento).
            </p>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">
              Assinatura padrão das mensagens (WhatsApp)
            </label>
            <textarea
              rows={2}
              value={formData.signature}
              onChange={(e) => setFormData({ ...formData, signature: e.target.value })}
              placeholder="Ex: Atenciosamente, Equipe Financeira"
              className="w-full bg-slate-100 border-none rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none text-slate-800"
            />
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="bg-blue-600 text-white text-sm font-semibold px-5 py-2.5 rounded-xl hover:bg-blue-700 transition-colors shadow-2xs active:scale-95"
            >
              Salvar todas as configurações
            </button>
          </div>
        </form>
      </div>

      {/* Backup & Synchronize Section */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Sincronização e Backup de Dados</h2>
              <p className="text-xs text-slate-500 font-mono">Exporte ou importe seus clientes e cobranças entre dispositivos ou links</p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Export Options */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">1. Exportar Dados deste Dispositivo</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={handleCopyBackupCode}
                className="flex items-center justify-center gap-2 p-3 bg-slate-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-800 transition-all shadow-2xs"
              >
                {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-300" />}
                {copiedCode ? 'Código de Backup Copiado!' : 'Copiar Código de Backup'}
              </button>

              <button
                type="button"
                onClick={handleExportJSON}
                className="flex items-center justify-center gap-2 p-3 bg-emerald-600 text-white rounded-xl text-xs font-semibold hover:bg-emerald-700 transition-all shadow-2xs"
              >
                <Download className="w-4 h-4" />
                Baixar Arquivo JSON (.json)
              </button>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-5 space-y-3">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">2. Importar / Restaurar Backup no Link de Produção</h3>
            <p className="text-xs text-slate-500">Cole o código de backup gerado ou selecione um arquivo JSON para carregar os clientes e cobranças neste dispositivo/link.</p>

            <div className="space-y-3">
              <textarea
                rows={3}
                value={importCodeInput}
                onChange={(e) => setImportCodeInput(e.target.value)}
                placeholder="Cole o código de backup ou JSON aqui..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-mono text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"
              />

              <div className="flex flex-wrap items-center justify-between gap-3">
                <label className="inline-flex items-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors">
                  <Upload className="w-3.5 h-3.5 text-slate-500" />
                  Carregar Arquivo .json
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>

                <button
                  type="button"
                  onClick={handleImportFromText}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-all shadow-2xs active:scale-95"
                >
                  Restaurar e Aplicar Dados
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
