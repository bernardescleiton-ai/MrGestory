import React, { useState, useEffect } from 'react';
import { X, User, FileText, Phone, Mail, FileEdit, Sparkles, Wand2, CheckCircle2 } from 'lucide-react';
import { Client } from '../types';

interface ClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (clientData: Omit<Client, 'id' | 'createdAt'>, editId?: string) => void;
  clientToEdit?: Client | null;
}

function parseDateAndTimeString(text: string): string {
  // Look for time HH:mm
  let timeStr = '00:00';
  const timeMatch = text.match(/\b([01]?\d|2[0-3])[:hH]([0-5]\d)\b/);
  if (timeMatch) {
    const hh = timeMatch[1].padStart(2, '0');
    const mm = timeMatch[2].padStart(2, '0');
    timeStr = `${hh}:${mm}`;
  }

  // Look for date: DD/MM/YYYY or YYYY-MM-DD
  const brDateMatch = text.match(/\b([0-3]?\d)[\/\.-]([0-1]?\d)[\/\.-](\d{2,4})\b/);
  if (brDateMatch) {
    const day = brDateMatch[1].padStart(2, '0');
    const month = brDateMatch[2].padStart(2, '0');
    let year = brDateMatch[3];
    if (year.length === 2) year = `20${year}`;
    return `${year}-${month}-${day}T${timeStr}`;
  }

  const isoDateMatch = text.match(/\b(\d{4})[\/\.-]([0-1]?\d)[\/\.-]([0-3]?\d)\b/);
  if (isoDateMatch) {
    const year = isoDateMatch[1];
    const month = isoDateMatch[2].padStart(2, '0');
    const day = isoDateMatch[3].padStart(2, '0');
    return `${year}-${month}-${day}T${timeStr}`;
  }

  return '';
}

function addOffsetToCurrentDate(months: number): string {
  const d = new Date();
  d.setMonth(d.getMonth() + months);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

export function parseClientText(rawText: string) {
  let name = '';
  let phone = '';
  let dueDate = '';
  let notes = '';

  if (!rawText || !rawText.trim()) {
    return { name, phone, dueDate, notes };
  }

  // 1. Extract phone number
  const phoneMatch = rawText.match(/(?:\+?55\s*)?(?:\(?\d{2}\)?\s*)?(?:9\s*)?\d{4}[-.\s]?\d{4}/);
  if (phoneMatch) {
    phone = phoneMatch[0].trim();
  }

  // 2. Check relative date keywords (e.g., 2 anos, 24 meses, 1 ano, 6 meses)
  if (/(\b2\s*anos?\b|\b24\s*meses?\b)/i.test(rawText)) {
    dueDate = addOffsetToCurrentDate(24);
  } else if (/(\b1\s*ano\b|\b12\s*meses?\b)/i.test(rawText)) {
    dueDate = addOffsetToCurrentDate(12);
  } else if (/(\b6\s*meses?\b)/i.test(rawText)) {
    dueDate = addOffsetToCurrentDate(6);
  } else {
    // Extract explicit date/time
    const parsedDt = parseDateAndTimeString(rawText);
    if (parsedDt) {
      dueDate = parsedDt;
    }
  }

  // 3. Process line by line or delimited by comma / hyphen / bar
  const lines = rawText.split('\n').map((l) => l.trim()).filter(Boolean);
  const remainingParts: string[] = [];

  for (const line of lines) {
    if (/^(nome|cliente|empresa|nome\/empresa|razao social)\s*[:=-]\s*/i.test(line)) {
      name = line.replace(/^(nome|cliente|empresa|nome\/empresa|razao social)\s*[:=-]\s*/i, '').trim();
      continue;
    }

    if (/^(whatsapp|whats|wpp|telefone|tel|celular|cel|fone)\s*[:=-]\s*/i.test(line)) {
      const extractedPhone = line.replace(/^(whatsapp|whats|wpp|telefone|tel|celular|cel|fone)\s*[:=-]\s*/i, '').trim();
      if (extractedPhone) phone = extractedPhone;
      continue;
    }

    if (/^(vencimento|vence|data|data de vencimento|venc)\s*[:=-]\s*/i.test(line)) {
      const extractedDateStr = line.replace(/^(vencimento|vence|data|data de vencimento|venc)\s*[:=-]\s*/i, '').trim();
      const dt = parseDateAndTimeString(extractedDateStr);
      if (dt) dueDate = dt;
      continue;
    }

    if (/^(obs|observação|observacoes|notas|nota|info|detalhes)\s*[:=-]\s*/i.test(line)) {
      notes = line.replace(/^(obs|observação|observacoes|notas|nota|info|detalhes)\s*[:=-]\s*/i, '').trim();
      continue;
    }

    // Split line by comma, semicolon, pipe, or hyphen if it looks like delimited record
    const segments = line.split(/[,;|]/).map((s) => s.trim()).filter(Boolean);
    for (const seg of segments) {
      remainingParts.push(seg);
    }
  }

  // Filter out segments that match phone or date
  const cleanSegments = remainingParts.map((part) => {
    let cleaned = part;
    if (phone) {
      cleaned = cleaned.replace(/(?:\+?55\s*)?(?:\(?\d{2}\)?\s*)?(?:9\s*)?\d{4}[-.\s]?\d{4}/g, '');
    }
    cleaned = cleaned.replace(/\b[0-3]?\d[\/\.-][0-1]?\d[\/\.-]\d{2,4}\b/g, '');
    cleaned = cleaned.replace(/\b\d{4}[\/\.-][0-1]?\d[\/\.-][0-3]?\d\b/g, '');
    cleaned = cleaned.replace(/\b([01]?\d|2[0-3])[:hH]([0-5]\d)\b/g, '');
    cleaned = cleaned.replace(/^[\s\-\|,:]+|[\s\-\|,:]+$/g, '').trim();
    return cleaned;
  }).filter(Boolean);

  if (!name && cleanSegments.length > 0) {
    name = cleanSegments[0];
  }

  if (!notes && cleanSegments.length > 1) {
    notes = cleanSegments.slice(1).join(' - ');
  }

  return { name, phone, dueDate, notes };
}

export const ClientModal: React.FC<ClientModalProps> = ({ isOpen, onClose, onSave, clientToEdit }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [notes, setNotes] = useState('');

  // Smart Paste state
  const [showSmartPaste, setShowSmartPaste] = useState(true);
  const [pasteInput, setPasteInput] = useState('');
  const [autoOrganizedAlert, setAutoOrganizedAlert] = useState<string | null>(null);

  useEffect(() => {
    if (clientToEdit) {
      setName(clientToEdit.name || '');
      setPhone(clientToEdit.phone || '');
      setDueDate(clientToEdit.dueDate || '');
      setNotes(clientToEdit.notes || '');
      setShowSmartPaste(false);
    } else {
      setName('');
      setPhone('');
      setDueDate('');
      setNotes('');
      setShowSmartPaste(true);
    }
    setPasteInput('');
    setAutoOrganizedAlert(null);
  }, [clientToEdit, isOpen]);

  if (!isOpen) return null;

  const handleAutoOrganize = () => {
    if (!pasteInput.trim()) {
      alert('Por favor, cole as informações do cliente no campo de texto.');
      return;
    }

    const parsed = parseClientText(pasteInput);

    if (parsed.name) setName(parsed.name);
    if (parsed.phone) setPhone(parsed.phone);
    if (parsed.dueDate) setDueDate(parsed.dueDate);
    if (parsed.notes) setNotes(parsed.notes);

    const filledCount = [parsed.name, parsed.phone, parsed.dueDate, parsed.notes].filter(Boolean).length;

    if (filledCount > 0) {
      setAutoOrganizedAlert(`${filledCount} campos organizados com sucesso! Verifique os dados abaixo.`);
      setTimeout(() => setAutoOrganizedAlert(null), 4000);
    } else {
      alert('Não foi possível identificar dados automaticamente no texto fornecido.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      alert('Por favor, preencha o Nome e o WhatsApp do cliente.');
      return;
    }
    onSave(
      {
        name: name.trim(),
        phone: phone.trim(),
        dueDate: dueDate ? dueDate : undefined,
        notes: notes.trim(),
      },
      clientToEdit ? clientToEdit.id : undefined
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50 shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
              {clientToEdit ? <FileEdit className="w-5 h-5" /> : <User className="w-5 h-5" />}
            </div>
            <h2 className="font-bold text-lg text-slate-800">
              {clientToEdit ? 'Editar Cliente' : 'Novo Cliente'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
          {!clientToEdit && (
            <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-blue-50 p-4 rounded-xl border-2 border-blue-200 shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-blue-900 uppercase tracking-wider">
                <Sparkles className="w-4 h-4 text-blue-600 animate-pulse shrink-0" />
                <span>Cole todas as informações do cliente de uma só vez:</span>
              </div>

              <textarea
                rows={3}
                value={pasteInput}
                onChange={(e) => {
                  const val = e.target.value;
                  setPasteInput(val);
                  if (val.trim()) {
                    const parsed = parseClientText(val);
                    if (parsed.name) setName(parsed.name);
                    if (parsed.phone) setPhone(parsed.phone);
                    if (parsed.dueDate) setDueDate(parsed.dueDate);
                    if (parsed.notes) setNotes(parsed.notes);
                  }
                }}
                placeholder={`Cole aqui: Nome, WhatsApp e Vencimento.\nExemplo:\nJoão Carlos\n(48) 99888-7766\n25/08/2026 14:30`}
                className="w-full p-3 bg-white border border-blue-300 rounded-xl text-xs font-mono text-slate-800 outline-none focus:ring-2 focus:ring-blue-500 placeholder:text-slate-400 shadow-inner"
              />

              <button
                type="button"
                onClick={handleAutoOrganize}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-md transition-all active:scale-[0.98]"
              >
                <Wand2 className="w-4 h-4" />
                Organizar nos Campos Automaticamente
              </button>

              {autoOrganizedAlert && (
                <div className="p-2.5 bg-emerald-100 text-emerald-800 text-xs rounded-lg font-bold flex items-center gap-2 border border-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{autoOrganizedAlert}</span>
                </div>
              )}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
              Nome / Empresa *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Ana Silva ou Empresa Ltda"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm text-slate-800"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                WhatsApp *
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="(48) 99999-9999"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm text-slate-800"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Data e Hora de Vencimento
              </label>
              <input
                type="datetime-local"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                min="2020-01-01T00:00"
                max="2036-12-31T23:59"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm text-slate-800 font-medium"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
              Observações
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Notas importantes sobre o cliente..."
              rows={3}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm text-slate-800 resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-semibold text-sm hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md shadow-blue-600/25 transition-colors"
            >
              Salvar Cliente
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

