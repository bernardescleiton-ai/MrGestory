import React from 'react';
import { Home, Users, Calendar, Bell, Settings as SettingsIcon, Briefcase, MessageSquare, Clock, RefreshCw } from 'lucide-react';
import { SectionType } from '../types';

interface SidebarProps {
  activeSection: SectionType;
  onSelectSection: (section: SectionType) => void;
  onSync?: () => void;
  isSyncing?: boolean;
  syncError?: string | null;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  activeSection, 
  onSelectSection, 
  onSync,
  isSyncing = false,
  syncError = null
}) => {
  const navItems: { id: SectionType; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <Home className="w-4 h-4 opacity-90" /> },
    { id: 'clients', label: 'Clientes', icon: <Users className="w-4 h-4 opacity-90" /> },
    { id: 'due', label: 'Vencimentos', icon: <Clock className="w-4 h-4 opacity-90" /> },
    { id: 'charges', label: 'Histórico', icon: <Calendar className="w-4 h-4 opacity-90" /> },
    { id: 'notifications', label: 'Alertas', icon: <MessageSquare className="w-4 h-4 opacity-90" /> },
    { id: 'settings', label: 'Dados', icon: <SettingsIcon className="w-4 h-4 opacity-90" /> },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-[#0F172A] text-slate-100 border-r border-slate-800 fixed inset-y-0 left-0 z-20">
        <div className="p-6 flex items-center space-x-3 border-b border-slate-800/60">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold shadow-sm">
            M
          </div>
          <span className="text-white font-bold tracking-tight text-base">MrGestor</span>
        </div>

        <nav className="flex-1 px-4 space-y-1 overflow-y-auto pt-2">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 px-2 mt-2">Principal</div>
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectSection(item.id)}
                className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl transition-colors text-left ${
                  isActive
                    ? 'bg-blue-600 text-white font-semibold shadow-sm'
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {item.icon}
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <div className="flex justify-between text-[11px] text-slate-400 mb-2 font-mono">
            <span>Sincronização Nuvem</span>
            {syncError ? (
              <span className="text-amber-400 font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                Local
              </span>
            ) : (
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                Tempo Real
              </span>
            )}
          </div>
          
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mb-2">
            <div className={`h-full w-full ${syncError ? 'bg-amber-500' : 'bg-emerald-500'}`}></div>
          </div>

          <div className="mt-1 flex items-center justify-between">
            <div className="text-[10px] text-slate-400 font-mono tracking-tight truncate max-w-[120px]">
              {syncError ? '💾 Salvo no Dispositivo' : '⚡ Nuvem Sincronizada'}
            </div>
            {onSync && (
              <button
                onClick={onSync}
                disabled={isSyncing}
                title="Sincronizar dados agora"
                className="flex items-center gap-1 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold px-2 py-1 rounded transition-all active:scale-95 disabled:opacity-50"
              >
                <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin text-blue-400' : ''}`} />
                {isSyncing ? 'Sincronizando...' : 'Sincronizar'}
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-[#0F172A]/95 backdrop-blur-md text-slate-300 border-t border-slate-800/80 flex justify-around items-center px-1 py-1.5 z-40 shadow-2xl">
        {navItems.map((item) => {
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectSection(item.id)}
              className={`flex-1 flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all min-h-[44px] active:scale-95 ${
                isActive
                  ? 'text-white bg-blue-600/90 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.icon}
              <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-full">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
