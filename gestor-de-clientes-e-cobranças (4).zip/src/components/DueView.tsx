import React from 'react';
import { Bell } from 'lucide-react';
import { Client, Charge, CompanySettings } from '../types';
import { dateBR, getChargeStatus, openWhatsApp } from '../utils/formatters';

interface DueViewProps {
  clients: Client[];
  charges: Charge[];
  settings: CompanySettings;
  onMarkPaid: (chargeId: string) => void;
  onSendWhatsApp?: (client: Client, charge?: Charge) => void;
}

export const DueView: React.FC<DueViewProps> = ({ clients, charges, settings, onMarkPaid, onSendWhatsApp }) => {
  const safeClients = Array.isArray(clients) ? clients : [];
  const safeCharges = Array.isArray(charges) ? charges : [];

  const getClient = (clientId: string) => safeClients.find((c) => c.id === clientId);

  // Gather all pending charges
  const chargeClientIds = new Set(safeCharges.filter((c) => !c.paid).map((c) => c.clientId));

  // Also build virtual charges for clients with dueDate who don't have an unpaid charge
  const clientCharges: Charge[] = safeClients
    .filter((cl) => cl.dueDate && !chargeClientIds.has(cl.id))
    .map((cl) => {
      const fullDt = cl.dueDate!;
      const [datePart, timePart] = fullDt.includes('T') ? fullDt.split('T') : [fullDt, ''];
      return {
        id: `client-charge-${cl.id}`,
        clientId: cl.id,
        amount: 0,
        dueDate: datePart,
        dueTime: timePart || undefined,
        paid: false,
        note: 'Vencimento do Cliente',
        createdAt: cl.createdAt,
      };
    });

  const pendingCharges = [...safeCharges.filter((c) => !c.paid), ...clientCharges].sort((a, b) =>
    a.dueDate.localeCompare(b.dueDate)
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Vencimentos</h1>
        <p className="text-slate-500 text-xs font-mono mt-0.5">Acompanhe todos os prazos e vencimentos pendentes e atrasados.</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-6">
        {pendingCharges.length === 0 ? (
          <div className="py-16 text-center">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
              <Bell className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-slate-800 text-base">Tudo em dia!</h3>
            <p className="text-slate-500 text-xs font-mono mt-1">Nenhum vencimento pendente no momento.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {pendingCharges.map((ch) => {
              const client = getClient(ch.clientId);
              const st = getChargeStatus(ch);
              return (
                <div
                  key={ch.id}
                  className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl border transition-all ${
                    st === 'late'
                      ? 'bg-rose-50/50 border-rose-200'
                      : 'bg-white border-slate-200 hover:border-blue-200'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800 text-sm">
                        {client ? client.name : 'Cliente removido'}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                          st === 'late'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {st === 'late' ? 'Atrasado' : 'Pendente'}
                      </span>
                    </div>

                    <div className="text-xs text-slate-600 flex flex-wrap items-center gap-3 font-mono">
                      <span>Vencimento: <strong className="text-slate-800">{dateBR(ch.dueDate)}{ch.dueTime ? ` às ${ch.dueTime}` : ''}</strong></span>
                      {ch.note && <span>• {ch.note}</span>}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-3 sm:mt-0 self-end sm:self-auto">
                    {client && (
                      <button
                        onClick={() => (onSendWhatsApp ? onSendWhatsApp(client, ch) : openWhatsApp(client, ch, settings))}
                        className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-semibold border border-emerald-200 transition-colors active:scale-95 flex items-center gap-1"
                      >
                        WhatsApp
                      </button>
                    )}
                    <button
                      onClick={() => onMarkPaid(ch.id)}
                      className="bg-blue-600 text-white text-xs font-semibold px-3 py-1.5 rounded-lg hover:bg-blue-700 transition-colors shadow-2xs"
                    >
                      Concluir
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
