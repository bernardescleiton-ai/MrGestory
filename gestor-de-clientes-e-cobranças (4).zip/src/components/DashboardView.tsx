import React from 'react';
import { Users, Calendar, AlertTriangle, ArrowRight, UserPlus, Bell, Settings, ChevronRight, Clock } from 'lucide-react';
import { AppData, SectionType, Client, Charge } from '../types';
import { dateBR, getChargeStatus, todayStr, openWhatsApp } from '../utils/formatters';

interface DashboardViewProps {
  data: AppData;
  onNavigate: (section: SectionType) => void;
  onOpenNewClient: () => void;
  onMarkPaid: (chargeId: string) => void;
  onSendWhatsApp?: (client: Client, charge?: Charge) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  data,
  onNavigate,
  onOpenNewClient,
  onMarkPaid,
  onSendWhatsApp,
}) => {
  const clients = Array.isArray(data?.clients) ? data.clients : [];
  const charges = Array.isArray(data?.charges) ? data.charges : [];
  const settings = data?.settings || {};

  const activeClientsCount = clients.length;
  const todayDateStr = todayStr();

  // Gather all pending charges + client due dates
  const chargeClientIds = new Set(charges.filter((c) => !c.paid).map((c) => c.clientId));
  const clientCharges: Charge[] = clients
    .filter((cl) => cl.dueDate && !chargeClientIds.has(cl.id))
    .map((cl) => {
      const fullDt = cl.dueDate!;
      const [datePart, timePart] = fullDt.includes('T') ? fullDt.split('T') : [fullDt, ''];
      return {
        id: `client-charge-${cl.id}`,
        clientId: cl.id,
        amount: 0,
        dueDate: datePart,
        dueTime: timePart || undefined,
        paid: false,
        note: 'Vencimento do Cliente',
        createdAt: cl.createdAt,
      };
    });

  const allPendingCharges = [...charges.filter((c) => !c.paid), ...clientCharges];

  // Due today count
  const dueTodayCount = allPendingCharges.filter((c) => c.dueDate === todayDateStr).length;

  // Upcoming due count (future dates)
  const upcomingCount = allPendingCharges.filter((c) => c.dueDate > todayDateStr).length;

  // Overdue count (late dates)
  const overdueCount = allPendingCharges.filter((c) => getChargeStatus(c) === 'late').length;

  const pendingCharges = allPendingCharges
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate))
    .slice(0, 5);

  const getClient = (clientId: string) => clients.find((cl) => cl.id === clientId);

  return (
    <div className="space-y-6">
      {/* Top bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Mister Gestor</h1>
        </div>

        {/* Action buttons header */}
        <div className="hidden sm:flex items-center gap-2">
          <button
            onClick={onOpenNewClient}
            className="bg-blue-600 text-white text-xs font-semibold px-4 py-2.5 rounded-xl hover:bg-blue-700 transition-all shadow-xs flex items-center justify-center gap-1.5 active:scale-95"
          >
            <UserPlus className="w-4 h-4" />
            <span>+ Novo Cliente</span>
          </button>
        </div>
      </div>

      {/* Quick Mobile Shortcut Grid */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-2xs">
        <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 px-1">Atalhos Rápidos</span>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button
            onClick={onOpenNewClient}
            className="p-3 bg-blue-50/70 hover:bg-blue-100/70 text-blue-900 rounded-xl flex items-center gap-2.5 transition-all text-left border border-blue-100 active:scale-95"
          >
            <div className="p-2 bg-blue-600 text-white rounded-lg shrink-0 shadow-xs">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <span className="block text-xs font-bold leading-tight">Novo Cliente</span>
              <span className="text-[10px] text-blue-600 font-mono">Cadastrar e agendar</span>
            </div>
          </button>

          <button
            onClick={() => onNavigate('notifications')}
            className="p-3 bg-indigo-50/70 hover:bg-indigo-100/70 text-indigo-900 rounded-xl flex items-center gap-2.5 transition-all text-left border border-indigo-100 active:scale-95"
          >
            <div className="p-2 bg-indigo-600 text-white rounded-lg shrink-0 shadow-xs">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <span className="block text-xs font-bold leading-tight">Alertas Gestor</span>
              <span className="text-[10px] text-indigo-600 font-mono">Lembretes WhatsApp</span>
            </div>
          </button>

          <button
            onClick={() => onNavigate('settings')}
            className="p-3 bg-slate-100/70 hover:bg-slate-200/70 text-slate-900 rounded-xl flex items-center gap-2.5 transition-all text-left border border-slate-200 active:scale-95"
          >
            <div className="p-2 bg-slate-800 text-white rounded-lg shrink-0 shadow-xs">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <span className="block text-xs font-bold leading-tight">Configurações</span>
              <span className="text-[10px] text-slate-500 font-mono">Modelo WhatsApp</span>
            </div>
          </button>
        </div>
      </div>

      {/* Interactive Metrics Cards (Purely Vencimentos & Clients Counts) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Clientes */}
        <button
          onClick={() => onNavigate('clients')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-2xs hover:border-blue-400 hover:shadow-md transition-all text-left group flex flex-col justify-between active:scale-95 relative overflow-hidden"
        >
          <div className="flex items-center justify-between w-full mb-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Total Clientes</span>
            <div className="p-2 bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white rounded-xl transition-colors">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between w-full">
            <div className="text-2xl font-extrabold text-slate-900">{activeClientsCount}</div>
            <div className="text-[11px] font-semibold text-blue-600 flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
              Ver <ChevronRight className="w-3 h-3" />
            </div>
          </div>
        </button>

        {/* Vencem Hoje */}
        <button
          onClick={() => onNavigate('due')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-2xs hover:border-amber-400 hover:shadow-md transition-all text-left group flex flex-col justify-between active:scale-95 relative overflow-hidden"
        >
          <div className="flex items-center justify-between w-full mb-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Vencem hoje</span>
            <div className="p-2 bg-amber-50 text-amber-600 group-hover:bg-amber-600 group-hover:text-white rounded-xl transition-colors">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between w-full">
            <div className="text-2xl font-extrabold text-amber-600">{dueTodayCount}</div>
            <div className="text-[11px] font-semibold text-amber-600 flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
              Ver <ChevronRight className="w-3 h-3" />
            </div>
          </div>
        </button>

        {/* Próximos Vencimentos */}
        <button
          onClick={() => onNavigate('due')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-2xs hover:border-blue-400 hover:shadow-md transition-all text-left group flex flex-col justify-between active:scale-95 relative overflow-hidden"
        >
          <div className="flex items-center justify-between w-full mb-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">A Vencer (Futuros)</span>
            <div className="p-2 bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white rounded-xl transition-colors">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between w-full">
            <div className="text-2xl font-extrabold text-blue-600">{upcomingCount}</div>
            <div className="text-[11px] font-semibold text-blue-600 flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform shrink-0">
              Ver <ChevronRight className="w-3 h-3" />
            </div>
          </div>
        </button>

        {/* Vencimentos Atrasados */}
        <button
          onClick={() => onNavigate('due')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-2xs hover:border-rose-400 hover:shadow-md transition-all text-left group flex flex-col justify-between active:scale-95 relative overflow-hidden"
        >
          <div className="flex items-center justify-between w-full mb-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Atrasados</span>
            <div className="p-2 bg-rose-50 text-rose-600 group-hover:bg-rose-600 group-hover:text-white rounded-xl transition-colors">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between w-full">
            <div className="text-2xl font-extrabold text-rose-600">{overdueCount}</div>
            <div className="text-[11px] font-semibold text-rose-600 flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform shrink-0">
              Ver <ChevronRight className="w-3 h-3" />
            </div>
          </div>
        </button>
      </div>

      {/* Next due list panel */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-200/80 flex items-center justify-between bg-slate-50/50">
          <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Próximos Vencimentos</h2>
          <button
            onClick={() => onNavigate('due')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 transition-colors active:scale-95"
          >
            Ver todos <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="p-4 sm:p-6">
          {pendingCharges.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm font-mono">
              Tudo em dia! Nenhum vencimento pendente no momento.
            </div>
          ) : (
            <div className="space-y-3">
              {pendingCharges.map((ch) => {
                const client = getClient(ch.clientId);
                const st = getChargeStatus(ch);
                return (
                  <div
                    key={ch.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 sm:p-4 rounded-xl border border-slate-200/90 hover:border-blue-300 bg-white gap-3 transition-all"
                  >
                    <div>
                      <div className="font-bold text-slate-900 text-sm">
                        {client ? client.name : 'Cliente removido'}
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5 flex flex-wrap items-center gap-1.5 font-mono">
                        <span>Vencimento: <strong className="text-slate-800">{dateBR(ch.dueDate)}</strong></span>
                        {ch.note && <span>• ({ch.note})</span>}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-auto w-full sm:w-auto justify-end">
                      <span
                        className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                          st === 'late'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {st === 'late' ? 'Atrasado' : 'Pendente'}
                      </span>

                      {client && (
                        <button
                          onClick={() => (onSendWhatsApp ? onSendWhatsApp(client, ch) : openWhatsApp(client, ch, settings))}
                          className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-semibold border border-emerald-200 transition-colors active:scale-95 flex items-center gap-1"
                        >
                          WhatsApp
                        </button>
                      )}

                      <button
                        onClick={() => onMarkPaid(ch.id)}
                        className="bg-blue-600 text-white text-xs font-semibold px-3 py-1.5 rounded-lg hover:bg-blue-700 transition-colors shadow-2xs active:scale-95"
                      >
                        Concluir
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
