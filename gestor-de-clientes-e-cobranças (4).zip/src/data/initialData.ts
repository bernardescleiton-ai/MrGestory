import { AppData } from '../types';

export const initialAppData: AppData = {
  settings: {
    name: 'MrGestor',
    phone: '(48) 99999-9999',
    address: 'Rua Principal, 100 - Florianópolis, SC',
    signature: 'Atenciosamente, Equipe MrGestor',
    messageTemplate: ''
  },
  clients: [
    {
      id: 'c-1',
      name: 'Ana Silva',
      phone: '48988881111',
      dueDate: '2026-08-10T14:30',
      notes: 'Cliente mensal - Manutenção de Site',
      createdAt: new Date().toISOString()
    },
    {
      id: 'c-2',
      name: 'Carlos Oliveira',
      phone: '48977772222',
      dueDate: '2026-08-15T10:00',
      notes: 'Projeto de Consultoria SEO',
      createdAt: new Date().toISOString()
    },
    {
      id: 'c-3',
      name: 'Mariana Souza',
      phone: '48966663333',
      dueDate: '2026-08-25T18:00',
      notes: 'Design de Identidade Visual',
      createdAt: new Date().toISOString()
    }
  ],
  charges: [
    {
      id: 'ch-1',
      clientId: 'c-1',
      amount: 0,
      dueDate: new Date().toISOString().slice(0, 10), // today
      note: 'Mensalidade Manutenção - Agosto',
      paid: false,
      messageSent: true,
      messageSentAt: new Date(Date.now() - 3600000).toISOString(),
      createdAt: new Date().toISOString()
    },
    {
      id: 'ch-2',
      clientId: 'c-2',
      amount: 0,
      dueDate: new Date(Date.now() - 3 * 86400000).toISOString().slice(0, 10), // 3 days ago (late)
      note: 'Consultoria SEO - Parcela 1/2',
      paid: false,
      messageSent: true,
      messageSentAt: new Date(Date.now() - 2 * 86400000).toISOString(),
      createdAt: new Date().toISOString()
    },
    {
      id: 'ch-3',
      clientId: 'c-3',
      amount: 0,
      dueDate: new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10), // in 5 days
      note: 'Criação de Logo e Manual',
      paid: true,
      paidAt: new Date().toISOString(),
      messageSent: true,
      messageSentAt: new Date(Date.now() - 1 * 86400000).toISOString(),
      createdAt: new Date().toISOString()
    }
  ],
  sentLogs: [
    {
      id: 'log-1',
      clientId: 'c-1',
      clientName: 'Ana Silva',
      phone: '48988881111',
      chargeId: 'ch-1',
      dueDate: new Date().toISOString().slice(0, 10),
      sentAt: new Date(Date.now() - 3600000).toISOString(),
      messageText: 'Olá, Ana Silva! Tudo bem?\n\nPassando para lembrar que seu vencimento está agendado para hoje.',
      note: 'Mensalidade Manutenção - Agosto',
      status: 'enviado'
    },
    {
      id: 'log-2',
      clientId: 'c-2',
      clientName: 'Carlos Oliveira',
      phone: '48977772222',
      chargeId: 'ch-2',
      dueDate: new Date(Date.now() - 3 * 86400000).toISOString().slice(0, 10),
      sentAt: new Date(Date.now() - 2 * 86400000).toISOString(),
      messageText: 'Olá, Carlos Oliveira! Tudo bem?\n\nPassando para lembrar sobre o vencimento da Consultoria SEO.',
      note: 'Consultoria SEO - Parcela 1/2',
      status: 'enviado'
    }
  ]
};
