import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, onSnapshot, setDoc, getDoc, getDocFromServer } from 'firebase/firestore';
import { AppData } from '../types';
import { initialAppData } from '../data/initialData';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

const APP_STATE_DOC_ID = 'main_state';

// Test connection on startup
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch {
    // Ignored in offline / quota scenarios
  }
}
testConnection();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: null,
      tenantId: null,
    },
    operationType,
    path,
  };
  console.warn('Firestore Notice: ', JSON.stringify(errInfo));
  throw new Error(errInfo.error);
}

// Memory hash to prevent duplicate ping-pong writes
let lastSavedHash = '';
let writeTimer: any = null;

function calculateDataHash(data: AppData): string {
  try {
    return `${data.clients?.length || 0}_${data.charges?.length || 0}_${data.updatedAt || 0}`;
  } catch {
    return String(data.updatedAt || Date.now());
  }
}

export function sanitizeDataForFirestore(obj: any): any {
  if (obj === null || obj === undefined) return null;
  if (Array.isArray(obj)) {
    return obj.map(sanitizeDataForFirestore);
  }
  if (typeof obj === 'object') {
    const sanitized: any = {};
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (val !== undefined) {
        sanitized[key] = sanitizeDataForFirestore(val);
      }
    }
    return sanitized;
  }
  return obj;
}

export async function fetchAppDataFromFirestore(): Promise<AppData | null> {
  try {
    const docRef = doc(db, 'app_state', APP_STATE_DOC_ID);
    const snapshot = await getDoc(docRef);
    if (snapshot.exists()) {
      const raw = snapshot.data();
      return {
        clients: Array.isArray(raw.clients) ? raw.clients : [],
        charges: Array.isArray(raw.charges) ? raw.charges : [],
        settings: { ...initialAppData.settings, ...(raw.settings || {}) },
        sentLogs: Array.isArray(raw.sentLogs) ? raw.sentLogs : [],
        updatedAt: typeof raw.updatedAt === 'number' ? raw.updatedAt : Date.now(),
      };
    }
    return null;
  } catch (err) {
    console.warn('Firestore fetch notice:', err);
    throw err;
  }
}

// Real-time listener for AppData from Firestore
export function subscribeToAppData(
  onData: (data: AppData, exists: boolean) => void,
  onError?: (err: Error) => void
) {
  const docRef = doc(db, 'app_state', APP_STATE_DOC_ID);

  const unsubscribe = onSnapshot(
    docRef,
    (snapshot) => {
      try {
        if (snapshot.exists()) {
          const raw = snapshot.data();
          if (raw) {
            const cloudData: AppData = {
              clients: Array.isArray(raw.clients) ? raw.clients : [],
              charges: Array.isArray(raw.charges) ? raw.charges : [],
              settings: { ...initialAppData.settings, ...(raw.settings || {}) },
              sentLogs: Array.isArray(raw.sentLogs) ? raw.sentLogs : [],
              updatedAt: typeof raw.updatedAt === 'number' ? raw.updatedAt : 0,
            };

            lastSavedHash = calculateDataHash(cloudData);
            onData(cloudData, true);
          }
        } else {
          onData(
            {
              clients: [],
              charges: [],
              settings: { ...initialAppData.settings },
              sentLogs: [],
              updatedAt: 0,
            },
            false
          );
        }
      } catch (e) {
        if (onError) onError(e instanceof Error ? e : new Error(String(e)));
      }
    },
    (error) => {
      console.warn('Firestore onSnapshot notice:', error?.message || error);
      if (onError) {
        onError(error);
      }
    }
  );

  return unsubscribe;
}

// Save AppData to Firestore (Debounced to respect rate limits)
export async function saveAppDataToFirestore(data: AppData, debounceMs: number = 400): Promise<void> {
  const currentHash = calculateDataHash(data);
  if (currentHash === lastSavedHash) {
    return;
  }

  if (writeTimer) {
    clearTimeout(writeTimer);
  }

  return new Promise<void>((resolve, reject) => {
    writeTimer = setTimeout(async () => {
      try {
        const docRef = doc(db, 'app_state', APP_STATE_DOC_ID);
        const payload = sanitizeDataForFirestore({
          clients: Array.isArray(data.clients) ? data.clients : [],
          charges: Array.isArray(data.charges) ? data.charges : [],
          settings: data.settings || {},
          sentLogs: Array.isArray(data.sentLogs) ? data.sentLogs : [],
          updatedAt: typeof data.updatedAt === 'number' ? data.updatedAt : Date.now(),
        });

        await setDoc(docRef, payload, { merge: true });
        lastSavedHash = currentHash;
        resolve();
      } catch (err: any) {
        console.warn('Firestore write notice:', err?.message || err);
        reject(err instanceof Error ? err : new Error(String(err)));
      }
    }, debounceMs);
  });
}
