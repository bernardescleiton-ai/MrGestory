import { AppData } from '../types';
import { initialAppData } from '../data/initialData';
import { subscribeToAppData, saveAppDataToFirestore, fetchAppDataFromFirestore } from './firebase';

export function sanitizeAppData(raw: any): AppData {
  if (!raw || typeof raw !== 'object') {
    return { ...initialAppData, updatedAt: Date.now() };
  }
  return {
    clients: Array.isArray(raw.clients) ? raw.clients : [],
    charges: Array.isArray(raw.charges) ? raw.charges : [],
    settings: {
      ...initialAppData.settings,
      ...(raw.settings && typeof raw.settings === 'object' ? raw.settings : {}),
    },
    sentLogs: Array.isArray(raw.sentLogs) ? raw.sentLogs : [],
    updatedAt: typeof raw.updatedAt === 'number' && raw.updatedAt > 0 ? raw.updatedAt : Date.now(),
  };
}

const isLocalServer = (): boolean => {
  if (typeof window === 'undefined') return false;
  const host = window.location.host;
  return host.includes('localhost:3000') || host.includes('127.0.0.1:3000');
};

// Fetch current state from Firestore or Local Server
export async function fetchAppData(): Promise<{ data: AppData | null; exists: boolean }> {
  // 1. Try direct Cloud Firestore first (works everywhere: Vercel, APK, Local)
  try {
    const cloudData = await fetchAppDataFromFirestore();
    if (cloudData) {
      return {
        data: sanitizeAppData(cloudData),
        exists: true,
      };
    }
  } catch (firestoreErr) {
    console.warn('Firestore fetch fallback:', firestoreErr);
  }

  // 2. If on local server, try /api/data
  if (isLocalServer()) {
    try {
      const res = await fetch('/api/data', {
        headers: { 'Accept': 'application/json' },
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          return {
            data: sanitizeAppData(json.data),
            exists: true,
          };
        }
      }
    } catch {
      // Local fallback
    }
  }

  return {
    data: null,
    exists: false,
  };
}

// Save state to Cloud Firestore and local server
export async function saveAppData(data: AppData, debounceMs: number = 300): Promise<void> {
  const safeData = sanitizeAppData(data);

  // 1. Save to Cloud Firestore
  try {
    await saveAppDataToFirestore(safeData, debounceMs);
  } catch (err) {
    console.warn('Cloud Firestore save notice:', err);
  }

  // 2. If running on local dev server, also post to /api/data
  if (isLocalServer()) {
    try {
      await fetch('/api/data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(safeData),
      });
    } catch {
      // Local fallback
    }
  }
}

// Real-time synchronization engine via Firestore onSnapshot
export function subscribeToApiData(
  onData: (data: AppData, exists: boolean) => void,
  onError?: (err: Error) => void
) {
  // Use direct Firestore real-time listener (works globally across Vercel, APK, Browser)
  return subscribeToAppData(
    (cloudData, exists) => {
      onData(sanitizeAppData(cloudData), exists);
    },
    (err) => {
      if (onError) onError(err);
    }
  );
}
